
```
## Usage
#### NOTE: First install Ollama run mistral(refer ollama documentation)

1. Install all the depenedencies :
   
```
pip install -r requirements.txt
```
2. Open terminal and run the following command:
```
streamlit run app.py
```
