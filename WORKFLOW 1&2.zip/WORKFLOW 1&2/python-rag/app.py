import streamlit as st
import pytesseract
import cv2
import numpy as np
from PIL import Image
from langchain_community.document_loaders import WebBaseLoader
from langchain_community.vectorstores import Chroma
from langchain_community import embeddings
from langchain_community.llms import Ollama
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain.text_splitter import CharacterTextSplitter

# Set the path to tesseract executable
pytesseract.pytesseract.tesseract_cmd = "C:\\Program Files\\Tesseract-OCR\\tesseract.exe"

# Function to process documents and perform RAG
def process_input(urls, question):
    model_local = Ollama(model="mistral")
    
    # Convert string of URLs to list
    urls_list = urls.split("\n")
    docs = [WebBaseLoader(url).load() for url in urls_list]
    docs_list = [item for sublist in docs for item in sublist]
    
    # Split the text into chunks
    text_splitter = CharacterTextSplitter.from_tiktoken_encoder(chunk_size=7500, chunk_overlap=100)
    doc_splits = text_splitter.split_documents(docs_list)
    
    # Convert text chunks into embeddings and store in vector database
    vectorstore = Chroma.from_documents(
        documents=doc_splits,
        collection_name="rag-chroma",
        embedding=embeddings.OllamaEmbeddings(model='nomic-embed-text'),
    )
    retriever = vectorstore.as_retriever()
    
    # Perform the RAG
    after_rag_template = """Answer the question based only on the following context:
    {context}
    Question: {question}
    """
    after_rag_prompt = ChatPromptTemplate.from_template(after_rag_template)
    after_rag_chain = (
        {"context": retriever, "question": RunnablePassthrough()}
        | after_rag_prompt
        | model_local
        | StrOutputParser()
    )
    return after_rag_chain.invoke(question)

# Streamlit app title
st.title("DocuMind")

# Section for uploading an image and converting it to text
st.header("Step 1: Upload an Image to Extract Text")
uploaded_file = st.file_uploader("Choose an image...", type=["png", "jpg", "jpeg"])

if uploaded_file is not None:
    # Convert the uploaded image to OpenCV format
    image = Image.open(uploaded_file)
    img = np.array(image)
    
    # Display the uploaded image
    st.image(img, caption='Uploaded Image.', use_column_width=True)
    
    # Convert image to text
    text = pytesseract.image_to_string(img)
    
    # Display the extracted text
    st.write("Extracted Text:")
    st.text_area("Text Output", text, height=200)

# Section for querying documents using the extracted text or manual input
st.header("Step 2: Query Documents with Extracted or Manual Question")
st.write("Enter URLs (one per line) and use the extracted text or manually enter a question to query the documents.")

# Input fields for URLs and question
urls = st.text_area("Enter URLs separated by new lines", height=150)
question = st.text_input("Enter Question (Or Use Extracted Text Above)")

# Button to set extracted text as the question
if st.button('Use Extracted Text as Question'):
    question = text
    st.text_input("Question", value=question)

# Button to process input and query documents
if st.button('Query Documents'):
    with st.spinner('Processing...'):
        answer = process_input(urls, question)
        st.text_area("Answer", value=answer, height=300, disabled=True)